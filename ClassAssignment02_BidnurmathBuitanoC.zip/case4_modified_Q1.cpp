#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* left;
    Node* right;

    Node(int value)
    {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

// Inorder (Left, Node, Right) prints a BST in sorted order
void printInorder(Node* node)
{
    if (node == nullptr) return;
    printInorder(node->left);
    cout << node->data << " ";
    printInorder(node->right);
}

// Free every node (postorder: children before parent)
void freeTree(Node* node)
{
    if (node == nullptr) return;
    freeTree(node->left);
    freeTree(node->right);
    delete node;
}

int main()
{
    // build tree T
    Node* root = new Node(40);
    root->left = new Node(20);
    root->right = new Node(60);
    root->left->left = new Node(10);
    root->left->right = new Node(30);
    root->right->left = new Node(50);
    root->right->right = new Node(70);

    cout << "Before: ";
    printInorder(root);
    cout << "  (root = " << root->data << ")" << endl;

    // Case 4 (Q1): delete a node with TWO children (60).
    // 1. search for 60
    Node* cur = root;
    int key = 60;                          // CHANGED: was 20
    while (cur != nullptr && cur->data != key)
    {
        if (key < cur->data) cur = cur->left;
        else                 cur = cur->right;
    }
    // 2. find the inorder successor: right once, then left as far as possible
    Node* parent = cur;
    Node* succ = cur->right;               // 70 (70 has no left child, loop does not run)
    while (succ->left != nullptr)
    {
        parent = succ;
        succ = succ->left;
    }
    // 3. copy the successor's value into the node
    cur->data = succ->data;                // the node that held 60 now holds 70
    // 4. remove the successor node (it has no left child)
    if (parent == cur)
        parent->right = succ->right;       // this branch runs: 60/70 node ->right = NULL
    else
        parent->left = succ->right;
    delete succ;

    cout << "After:  ";
    printInorder(root);
    cout << "  (root = " << root->data << ")" << endl;

    freeTree(root);
    return 0;
}